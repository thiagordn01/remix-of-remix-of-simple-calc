# 🎤 Gerador de Áudio - Sistema com Login Integrado

## ⚡ INSTALAÇÃO RÁPIDA

### 1. Instalar dependências:
```bash
pip install -r requirements.txt
```

### 2. Executar:
```bash
python run_gui.py
```

## 🔐 SISTEMA DE LOGIN

Quando você executar, vai aparecer uma tela de login ANTES do programa principal.

**Use o email e senha que foram enviados para você após a compra no Kiwify.**

### Exemplo:
```
Email: cliente@email.com
Senha: abc123def456
```

## ✨ FUNCIONALIDADES

- ✅ **Login automático**: Salva sua sessão, não precisa logar toda vez
- ✅ **Aviso de expiração**: Te avisa quando seu acesso está perto de expirar
- ✅ **Validação de acesso**: Verifica se sua conta está ativa e aprovada
- ✅ **Interface dourada**: Design profissional integrado com o sistema

## 🔧 GERAR EXECUTÁVEL (.exe)

Se você quer distribuir como executável:

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name "GeradorAudio" run_gui.py
```

O arquivo .exe vai estar na pasta `dist/`

## ❓ PROBLEMAS?

### "Erro de conexão" ou "Timeout"
- Verifique sua internet
- O sistema precisa se conectar ao servidor para validar o login

### "Email ou senha incorretos"
- Verifique se está usando o email/senha que recebeu no email
- Verifique se não tem espaços antes/depois

### "Sua conta ainda não foi aprovada"
- Entre em contato com o suporte
- O administrador precisa aprovar sua conta

### "Seu acesso expirou"
- Seu período de acesso terminou
- Entre em contato para renovar

## 📋 REQUISITOS

- Python 3.8+
- PyQt6
- requests
- Internet (para fazer login)

## 🎯 ESTRUTURA DO PROJETO

```
ferramenta-audio-charles/
├── run_gui.py           # Arquivo principal (execute este)
├── auth_manager.py      # Gerenciador de autenticação
├── tela_login.py        # Interface de login
├── requirements.txt     # Dependências
└── COMO_USAR.md        # Este arquivo
```

## 🚀 PRÓXIMOS PASSOS

Depois de testar e confirmar que funciona:

1. Gere o executável com PyInstaller
2. Teste em outra máquina sem Python instalado
3. Distribua para seus clientes

---

**SUPORTE:** Se tiver qualquer problema, entre em contato!
