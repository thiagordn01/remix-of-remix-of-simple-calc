#!/usr/bin/env python3
"""
Script principal para executar a interface gráfica do ContentFlow Text to Speech.
"""

import sys
import os
import traceback
import logging
import multiprocessing
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QIcon
from gui_text_to_speech import CompactTextToSpeechGUI

def setup_logging():
    """Configura o sistema de logging para salvar logs em um arquivo."""
    # Garante que o diretório de logs exista
    # Usa um diretório de dados de aplicativo específico do usuário para garantir persistência e acessibilidade
    app_data_dir = os.path.join(os.path.expanduser("~"), "AppData", "Local", "CharlesNetworkingTTS", "Logs")
    os.makedirs(app_data_dir, exist_ok=True)
    log_file = os.path.join(app_data_dir, "app.log")

    # Configura o logger
    logging.basicConfig(
        level=logging.DEBUG, # Alterado para DEBUG
        format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(log_file, mode='a', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

    # Redireciona exceções não capturadas para o log
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logging.critical("Exceção não capturada:", exc_info=(exc_type, exc_value, exc_traceback))

    sys.excepthook = handle_exception
    logging.info("Sistema de log configurado. Logs serão salvos em: %s", log_file)
    logging.info("Verifique este arquivo para logs detalhados de debug e erros.")

def main():
    """Função principal para executar a aplicação."""
    # Adiciona o diretório atual ao path para garantir que os módulos locais sejam encontrados
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    # Configura o logging antes de qualquer outra coisa
    setup_logging()
    
    logging.info("Iniciando aplicação...")
    
    try:
        app = QApplication(sys.argv)
        
        # Define o ícone da aplicação, se existir
        icon_path = os.path.join(os.path.dirname(__file__), "icon.ico")
        if os.path.exists(icon_path):
            app.setWindowIcon(QIcon(icon_path))
            logging.info("Ícone da aplicação carregado.")
        else:
            logging.warning("Arquivo de ícone 'icon.ico' não encontrado.")
        
        window = CompactTextToSpeechGUI()
        window.show()
        
        logging.info("Interface gráfica iniciada com sucesso.")
        
        exit_code = app.exec()
        logging.info("Aplicação finalizada com código de saída: %d", exit_code)
        sys.exit(exit_code)

    except Exception:
        logging.critical("Falha crítica ao iniciar a interface gráfica.", exc_info=True)
        # Tenta mostrar um erro para o usuário se o console fechar
        # Este é um último recurso
        with open("critical_error.log", "w", encoding="utf-8") as f:
            f.write("Ocorreu um erro crítico ao iniciar a aplicação.\n")
            f.write("Por favor, verifique o arquivo 'app.log' para detalhes técnicos.\n\n")
            traceback.print_exc(file=f)
        
        # Se possível, exibe uma mensagem antes de fechar
        try:
            from PyQt6.QtWidgets import QMessageBox
            # Necessário criar uma app dummy se a principal falhou
            dummy_app = QApplication.instance() or QApplication([])
            QMessageBox.critical(None, "Erro Crítico", 
                                 "A aplicação falhou ao iniciar. Verifique o arquivo 'app.log' para detalhes.")
        except:
            # Fallback para console
            print("ERRO CRÍTICO: A aplicação falhou ao iniciar. Verifique o arquivo 'app.log' para detalhes.")
            input("Pressione Enter para fechar...")
        
        sys.exit(1)

if __name__ == "__main__":
    # Necessário para PyInstaller em Windows e macOS
    multiprocessing.freeze_support()
    main()