#!/usr/bin/env python3
"""
Script principal para executar a interface gráfica do ContentFlow Text to Speech.
AGORA COM AUTENTICAÇÃO INTEGRADA!
"""

import sys
import os
import traceback
import logging
import multiprocessing
from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtGui import QIcon
from gui_text_to_speech import CompactTextToSpeechGUI
from tela_login import TelaLogin

def setup_logging():
    """Configura o sistema de logging para salvar logs em um arquivo."""
    # Garante que o diretório de logs exista
    # Usa um diretório de dados de aplicativo específico do usuário para garantir persistência e acessibilidade
    app_data_dir = os.path.join(os.path.expanduser("~"), "AppData", "Local", "CharlesNetworkingTTS", "Logs")
    os.makedirs(app_data_dir, exist_ok=True)
    log_file = os.path.join(app_data_dir, "app.log")

    # Configura o logger
    logging.basicConfig(
        level=logging.DEBUG, # Alterado para DEBUG
        format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(log_file, mode='a', encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

    # Redireciona exceções não capturadas para o log
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logging.critical("Exceção não capturada:", exc_info=(exc_type, exc_value, exc_traceback))

    sys.excepthook = handle_exception
    logging.info("Sistema de log configurado. Logs serão salvos em: %s", log_file)
    logging.info("Verifique este arquivo para logs detalhados de debug e erros.")

def iniciar_programa_principal(auth_manager, app):
    """
    Inicia o programa principal após login bem-sucedido

    Args:
        auth_manager: Instância do AuthManager com usuário logado
        app: Instância do QApplication

    Returns:
        CompactTextToSpeechGUI: Janela principal criada
    """
    logging.info(f"Usuário autenticado: {auth_manager.obter_nome_usuario()}")
    logging.info(f"Email: {auth_manager.obter_email_usuario()}")

    dias = auth_manager.obter_dias_restantes()
    if dias:
        logging.info(f"Dias restantes de acesso: {dias}")

        # Alertar se acesso está próximo de expirar
        if dias <= 7:
            QMessageBox.warning(
                None,
                "Atenção - Acesso Próximo de Expirar",
                f"⚠️ Seu acesso expira em {dias} dia(s)!\n\n"
                "Por favor, renove sua assinatura para continuar usando o sistema."
            )
    else:
        logging.info("Usuário tem acesso permanente")

    try:
        # Define o ícone da aplicação, se existir
        icon_path = os.path.join(os.path.dirname(__file__), "icon.ico")
        if os.path.exists(icon_path):
            app.setWindowIcon(QIcon(icon_path))
            logging.info("Ícone da aplicação carregado.")
        else:
            logging.warning("Arquivo de ícone 'icon.ico' não encontrado.")

        # Criar e mostrar janela principal
        window = CompactTextToSpeechGUI()
        window.show()

        logging.info("Interface gráfica iniciada com sucesso.")

        return window

    except Exception:
        logging.critical("Falha crítica ao iniciar a interface gráfica.", exc_info=True)
        with open("critical_error.log", "w", encoding="utf-8") as f:
            f.write("Ocorreu um erro crítico ao iniciar a aplicação.\n")
            f.write("Por favor, verifique o arquivo 'app.log' para detalhes técnicos.\n\n")
            traceback.print_exc(file=f)

        try:
            QMessageBox.critical(None, "Erro Crítico",
                                 "A aplicação falhou ao iniciar. Verifique o arquivo 'app.log' para detalhes.")
        except:
            print("ERRO CRÍTICO: A aplicação falhou ao iniciar. Verifique o arquivo 'app.log' para detalhes.")
            input("Pressione Enter para fechar...")

        sys.exit(1)

def main():
    """Função principal para executar a aplicação."""
    # Adiciona o diretório atual ao path para garantir que os módulos locais sejam encontrados
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    # Configura o logging antes de qualquer outra coisa
    setup_logging()

    logging.info("="*60)
    logging.info("Iniciando aplicação ContentFlow TTS com autenticação...")
    logging.info("="*60)

    try:
        # Criar aplicação Qt
        app = QApplication(sys.argv)

        # Definir informações da aplicação
        app.setApplicationName("ContentFlow TTS")
        app.setOrganizationName("Charles Networking")

        logging.info("Exibindo tela de login...")

        # Variável para armazenar a janela principal
        main_window = None

        # Callback para criar janela principal após login
        def on_login_ok(auth):
            nonlocal main_window
            main_window = iniciar_programa_principal(auth, app)

        # Mostrar tela de login primeiro
        tela_login = TelaLogin(on_login_success=on_login_ok)

        # Executar tela de login como modal
        resultado = tela_login.exec()

        if resultado != tela_login.DialogCode.Accepted:
            # Usuário fechou a janela sem fazer login
            logging.info("Login cancelado pelo usuário. Encerrando aplicação.")
            sys.exit(0)

        # Se chegou aqui, login foi bem-sucedido e janela principal foi criada
        # Agora executar o event loop principal
        if main_window:
            exit_code = app.exec()
            logging.info("Aplicação finalizada com código de saída: %d", exit_code)
            sys.exit(exit_code)
        else:
            logging.error("Janela principal não foi criada após login.")
            sys.exit(1)

    except Exception as e:
        logging.critical(f"Erro fatal ao iniciar aplicação: {e}", exc_info=True)

        try:
            QMessageBox.critical(
                None,
                "Erro Fatal",
                f"Falha ao iniciar a aplicação:\n\n{str(e)}\n\nVerifique o arquivo 'app.log' para mais detalhes."
            )
        except:
            print(f"ERRO FATAL: {e}")
            input("Pressione Enter para fechar...")

        sys.exit(1)

if __name__ == "__main__":
    # Necessário para PyInstaller em Windows e macOS
    multiprocessing.freeze_support()
    main()