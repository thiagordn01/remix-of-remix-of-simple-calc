"""
Tela de Login para Executáveis Python
Interface gráfica usando PyQt6
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QCheckBox, QMessageBox, QWidget
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QIcon
from auth_manager import AuthManager


class TelaLogin(QDialog):
    """
    Interface gráfica de login usando PyQt6
    """

    def __init__(self, on_login_success, parent=None):
        """
        Inicializa tela de login

        Args:
            on_login_success: Função callback chamada quando login for bem-sucedido
                             Recebe o AuthManager como parâmetro
            parent: Widget pai (opcional)
        """
        super().__init__(parent)
        self.auth = AuthManager()
        self.on_login_success = on_login_success

        # Configurar janela
        self.setWindowTitle("Login - Sistema Charles")
        self.setFixedSize(500, 400)
        self.setModal(True)

        # Estilo
        self._configurar_estilo()

        # Criar interface
        self._criar_interface()

        # Verificar se já tem sessão salva
        QTimer.singleShot(100, self._verificar_sessao_salva)

    def _configurar_estilo(self):
        """Configura estilo visual da interface"""
        # Cor dourada do sistema
        self.cor_dourada = "#D4AF37"
        self.cor_dourada_hover = "#F59E0B"

        # Aplicar stylesheet global
        self.setStyleSheet(f"""
            QDialog {{
                background-color: #f5f5f5;
            }}
            QLabel {{
                color: #333333;
                font-size: 13px;
            }}
            QLineEdit {{
                padding: 12px;
                border: 2px solid #cccccc;
                border-radius: 6px;
                font-size: 14px;
                background-color: #ffffff;
                color: #000000;
                selection-background-color: {self.cor_dourada};
                selection-color: white;
            }}
            QLineEdit:focus {{
                border-color: {self.cor_dourada};
                background-color: #ffffff;
            }}
            QLineEdit::placeholder {{
                color: #999999;
            }}
            QCheckBox {{
                color: #333333;
                font-size: 12px;
            }}
            QPushButton#btnLogin {{
                background-color: {self.cor_dourada};
                color: white;
                border: none;
                padding: 12px;
                font-size: 15px;
                font-weight: bold;
                border-radius: 8px;
            }}
            QPushButton#btnLogin:hover {{
                background-color: {self.cor_dourada_hover};
            }}
            QPushButton#btnLogin:pressed {{
                background-color: #FBBF24;
            }}
            QPushButton#btnLogin:disabled {{
                background-color: #cccccc;
                color: #666666;
            }}
        """)

    def _criar_interface(self):
        """Cria todos os elementos visuais da interface"""
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(40, 30, 40, 30)

        # ===== HEADER =====
        header_widget = QWidget()
        header_widget.setStyleSheet(f"""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 {self.cor_dourada},
                stop:0.5 #F59E0B,
                stop:1 #FBBF24);
            border-radius: 8px;
            padding: 20px;
        """)
        header_layout = QVBoxLayout(header_widget)

        titulo = QLabel("🔐 Acesso ao Sistema")
        titulo.setStyleSheet("color: white; font-size: 24px; font-weight: bold; background: transparent;")
        titulo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(titulo)

        layout.addWidget(header_widget)
        layout.addSpacing(20)

        # ===== CAMPO EMAIL =====
        email_label = QLabel("Email:")
        email_label.setStyleSheet("font-weight: bold; font-size: 13px; color: #333333;")
        layout.addWidget(email_label)

        self.email_entry = QLineEdit()
        self.email_entry.setPlaceholderText("Digite seu email...")
        self.email_entry.setMinimumHeight(45)
        self.email_entry.returnPressed.connect(self._processar_login)
        layout.addWidget(self.email_entry)

        # ===== CAMPO SENHA =====
        senha_label = QLabel("Senha:")
        senha_label.setStyleSheet("font-weight: bold; font-size: 13px; color: #333333;")
        layout.addWidget(senha_label)

        self.senha_entry = QLineEdit()
        self.senha_entry.setPlaceholderText("Digite sua senha...")
        self.senha_entry.setMinimumHeight(45)
        self.senha_entry.setEchoMode(QLineEdit.EchoMode.Password)
        self.senha_entry.returnPressed.connect(self._processar_login)
        layout.addWidget(self.senha_entry)

        # ===== CHECKBOX "LEMBRAR" =====
        self.lembrar_check = QCheckBox("Lembrar meu login")
        self.lembrar_check.setChecked(True)
        self.lembrar_check.setStyleSheet("font-size: 11px;")
        layout.addWidget(self.lembrar_check)

        layout.addSpacing(10)

        # ===== BOTÃO ENTRAR =====
        self.btn_login = QPushButton("✨ ENTRAR ✨")
        self.btn_login.setObjectName("btnLogin")
        self.btn_login.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_login.setMinimumHeight(50)
        self.btn_login.clicked.connect(self._processar_login)
        layout.addWidget(self.btn_login)

        # ===== LABEL DE STATUS =====
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: red; font-size: 11px;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()

        self.setLayout(layout)

        # Focar no campo de email
        self.email_entry.setFocus()

    def _verificar_sessao_salva(self):
        """Verifica se existe sessão salva e faz login automático"""
        if self.auth.verificar_acesso_ativo():
            # Já tem sessão salva
            nome = self.auth.obter_nome_usuario()
            dias = self.auth.obter_dias_restantes()

            if dias is not None and dias <= 0:
                # Acesso expirado
                QMessageBox.warning(
                    self,
                    "Acesso Expirado",
                    "Sua sessão anterior expirou. Por favor, faça login novamente."
                )
                self.auth.fazer_logout()
                return

            # Perguntar se quer continuar com sessão salva
            if dias:
                mensagem = f"Bem-vindo de volta, {nome}!\n\nAcesso expira em {dias} dia(s).\n\nDeseja continuar?"
            else:
                mensagem = f"Bem-vindo de volta, {nome}!\n\nVocê tem acesso permanente.\n\nDeseja continuar?"

            resposta = QMessageBox.question(
                self,
                "Sessão Anterior Encontrada",
                mensagem,
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )

            if resposta == QMessageBox.StandardButton.Yes:
                # Continuar com sessão salva
                self.accept()
                self.on_login_success(self.auth)
            else:
                # Fazer logout e pedir novo login
                self.auth.fazer_logout()

    def _processar_login(self):
        """Processa tentativa de login"""
        email = self.email_entry.text().strip()
        senha = self.senha_entry.text()

        # Validar campos vazios
        if not email:
            self.status_label.setText("⚠️ Por favor, digite seu email")
            self.email_entry.setFocus()
            return

        if not senha:
            self.status_label.setText("⚠️ Por favor, digite sua senha")
            self.senha_entry.setFocus()
            return

        # Desabilitar interface durante processamento
        self.btn_login.setEnabled(False)
        self.btn_login.setText("VERIFICANDO...")
        self.email_entry.setEnabled(False)
        self.senha_entry.setEnabled(False)
        self.status_label.setText("🔄 Conectando ao servidor...")
        self.status_label.setStyleSheet("color: blue; font-size: 11px;")

        # Processar eventos pendentes para atualizar UI
        self.repaint()

        # Tentar fazer login
        sucesso, mensagem = self.auth.fazer_login(email, senha)

        if sucesso:
            # ✅ Login bem-sucedido
            self.status_label.setText("✅ Login bem-sucedido!")
            self.status_label.setStyleSheet("color: green; font-size: 11px;")
            self.repaint()

            # Se marcou "não lembrar", limpar sessão
            if not self.lembrar_check.isChecked():
                self.auth.fazer_logout()

            # Aguardar 1 segundo para usuário ver mensagem
            QTimer.singleShot(1000, lambda: self._finalizar_login_sucesso())

        else:
            # ❌ Login falhou
            self.status_label.setText(f"❌ {mensagem}")
            self.status_label.setStyleSheet("color: red; font-size: 11px;")

            # Re-habilitar interface
            self.btn_login.setEnabled(True)
            self.btn_login.setText("✨ ENTRAR ✨")
            self.email_entry.setEnabled(True)
            self.senha_entry.setEnabled(True)

            # Limpar senha e focar nela
            self.senha_entry.clear()
            self.senha_entry.setFocus()

    def _finalizar_login_sucesso(self):
        """Finaliza processo de login bem-sucedido"""
        self.accept()
        self.on_login_success(self.auth)


# ===== EXEMPLO DE USO =====

if __name__ == "__main__":
    """
    Teste da tela de login
    """
    from PyQt6.QtWidgets import QApplication
    import sys

    def ao_fazer_login(auth_manager):
        """Callback chamado quando login for bem-sucedido"""
        print("\n" + "="*50)
        print("✅ LOGIN BEM-SUCEDIDO!")
        print("="*50)
        print(f"Nome: {auth_manager.obter_nome_usuario()}")
        print(f"Email: {auth_manager.obter_email_usuario()}")

        dias = auth_manager.obter_dias_restantes()
        if dias:
            print(f"Dias restantes: {dias}")
        else:
            print("Acesso: Permanente")

        print("="*50)

        # Aqui você iniciaria seu programa principal
        QMessageBox.information(None, "Sucesso", f"Login realizado com sucesso!\n\nBem-vindo, {auth_manager.obter_nome_usuario()}!")
        sys.exit(0)

    # Criar aplicação
    app = QApplication(sys.argv)

    # Mostrar tela de login
    tela = TelaLogin(on_login_success=ao_fazer_login)

    if tela.exec() == QDialog.DialogCode.Accepted:
        # Login foi bem-sucedido, programa continua
        pass
    else:
        # Usuário fechou a janela sem fazer login
        sys.exit(0)
