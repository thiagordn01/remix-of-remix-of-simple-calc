import sys
import os
import subprocess
import threading
import time
import asyncio
import edge_tts
import glob
import json
import re # Importa a biblioteca re
from pathlib import Path
from PyQt6.QtCore import QStandardPaths # Importa QStandardPaths

# Adiciona C:\ffmpeg\bin ao PATH se existir (para Windows)
if os.name == 'nt':  # Windows
    ffmpeg_paths = [
        r"C:\ffmpeg\bin",
        r"C:\Program Files\ffmpeg\bin",
        r"C:\Program Files (x86)\ffmpeg\bin"
    ]
    for ffmpeg_path in ffmpeg_paths:
        if os.path.exists(ffmpeg_path) and ffmpeg_path not in os.environ.get('PATH', ''):
            os.environ['PATH'] = ffmpeg_path + os.pathsep + os.environ.get('PATH', '')

from PyQt6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                            QWidget, QPushButton, QLabel, QLineEdit, QComboBox,
                            QTextEdit, QProgressBar, QFileDialog, QListWidget,
                            QListWidgetItem, QInputDialog, QMessageBox, QGroupBox, QScrollArea, QSlider)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QUrl
from PyQt6.QtGui import QIcon, QPixmap, QColor, QPalette
from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
import text_to_speech_processor as tts

# Define flags para subprocessos no Windows para evitar a criação de janelas de console
subprocess_flags = 0
if os.name == 'nt':
    subprocess_flags = subprocess.CREATE_NO_WINDOW

# Caminhos para salvar configurações
# Usa um diretório de dados de aplicativo específico do usuário para garantir persistência
app_data_dir = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
# Cria um subdiretório para o seu aplicativo, se desejar
app_specific_dir = os.path.join(app_data_dir, "CharlesNetworkingTTS")
PRESETS_FILE = os.path.join(app_specific_dir, "voice_presets.json")

class VoiceLoaderThread(QThread):
    voices_loaded = pyqtSignal(list)
    error_occurred = pyqtSignal(str)
    
    def run(self):
        try:
            # Use asyncio to run the async list_voices function
            voices_data = asyncio.run(edge_tts.list_voices())
            voices = [(voice['Name'], voice['Gender']) for voice in voices_data]
            self.voices_loaded.emit(voices)
        except Exception as e:
            # Capture any exception, including from asyncio and edge_tts
            error_message = f"Falha ao carregar vozes: {e}\n" \
                            "Verifique sua conexão com a internet e se o edge-tts está instalado corretamente."
            self.error_occurred.emit(error_message)

class PreviewThread(QThread):
    preview_ready = pyqtSignal(str)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, voice, rate, pitch, language, parent=None): # Adiciona 'language'
        super().__init__(parent)
        self.voice = voice
        self.rate = rate
        self.pitch = pitch
        self.language = language
    
    def run(self):
        try:
            import tempfile
            import os
            
            # Texto de exemplo em português (15 segundos aproximadamente)
            preview_texts = {
                'pt-BR': 'Olá! Esta é uma demonstração completa da minha voz. Eu posso narrar seus textos com clareza, naturalidade e expressividade. Minha pronúncia é clara e o ritmo é agradável. Experimente usar esta voz para seus projetos de áudio, vídeos, apresentações e muito mais. Obrigado por testar!',
                'pt-PT': 'Olá! Esta é uma demonstração completa da minha voz. Eu posso narrar os seus textos com clareza, naturalidade e expressividade. A minha pronúncia é clara e o ritmo é agradável. Experimente usar esta voz para os seus projetos de áudio, vídeos, apresentações e muito mais. Obrigado por testar!',
                'en-': 'Hello! This is a complete demonstration of my voice. I can narrate your texts with clarity, naturalness and expressiveness. My pronunciation is clear and the rhythm is pleasant. Try using this voice for your audio projects, videos, presentations and much more. Thank you for testing!',
                'es-': '¡Hola! Esta es una demostración completa de mi voz. Puedo narrar tus textos con claridad, naturalidad y expresividad. Mi pronunciación es clara y el ritmo es agradable. Prueba a usar esta voz para tus proyectos de audio, vídeos, presentaciones y mucho más. ¡Gracias por probar!',
                'fr-': 'Bonjour! Ceci est une démonstration complète de ma voix. Je peux narrer vos textes avec clarté, naturel et expressivité. Ma prononciation est claire et le rythme est agréable. Essayez cette voix pour vos projets audio, vidéos, présentations et bien plus encore. Merci de tester!',
                'de-': 'Hallo! Dies ist eine vollständige Demonstration meiner Stimme. Ich kann Ihre Texte mit Klarheit, Natürlichkeit und Ausdruckskraft erzählen. Meine Aussprache ist klar und der Rhythmus ist angenehm. Probieren Sie diese Stimme für Ihre Audioprojekte, Videos, Präsentationen und vieles mehr. Danke fürs Testen!',
                'it-': 'Ciao! Questa è una dimostrazione completa della mia voce. Posso narrare i tuoi testi con chiarezza, naturalezza ed espressività. La mia pronuncia è chiara e il ritmo è piacevole. Prova questa voce per i tuoi progetti audio, video, presentazioni e molto altro. Grazie per aver testato!',
                'zh-': '你好！这是我的声音的完整演示。我可以清晰、自然、富有表现力地叙述您的文本。我的发音清晰，节奏舒适。尝试将这个声音用于您的音频项目、视频、演示文稿等。感谢您的测试！',
                'ja-': 'こんにちは！これは私の声の完全なデモンストレーションです。明瞭さ、自然さ、表現力を持ってテキストをナレーションできます。発音は明瞭でリズムは心地よいです。オーディオプロジェクト、ビデオ、プレゼンテーションなどにこの声をお試しください。テストしていただきありがとうございます！',
                'ko-': '안녕하세요! 이것은 제 목소리의 완전한 시연입니다. 명확성, 자연스러움 및 표현력으로 텍스트를 내레이션할 수 있습니다. 제 발음은 명확하고 리듬은 즐겁습니다. 오디오 프로젝트, 비디오, 프레젠테이션 등에 이 음성을 사용해 보세요. 테스트해 주셔서 감사합니다!',
                'ru-': 'Привет! Это полная демонстрация моего голоса. Я могу озвучивать ваши тексты с ясностью, естественностью и выразительностью. Моё произношение чёткое, а ритм приятный. Попробуйте использовать этот голос для аудиопроектов, видео, презентаций и многого другого. Спасибо за тестирование!',
                'ar-': 'مرحبا! هذا عرض توضيحي كامل لصوتي. يمكنني سرد نصوصك بوضوح وطبيعية وتعبيرية. نطقي واضح والإيقاع ممتع. جرب استخدام هذا الصوت لمشاريع الصوت ومقاطع الفيديو والعروض التقديمية وغير ذلك الكثير. شكرا لك على الاختبار!',
            }
            
            # Escolhe texto baseado no idioma selecionado
            preview_text = preview_texts.get(self.language, preview_texts.get('en-US', 'Hello! This is a test.'))
            if self.language == "auto":
                # Tenta encontrar um texto de preview baseado no idioma da voz se a detecção automática estiver ativada
                voice_lang_code_match = re.search(r'([a-zA-Z]{2}\-[a-zA-Z]{2})', self.voice)
                if voice_lang_code_match:
                    voice_lang_code = voice_lang_code_match.group(1)
                    preview_text = preview_texts.get(voice_lang_code, preview_texts.get('en-US', 'Hello! This is a test.'))
                else:
                    preview_text = preview_texts.get('en-US', 'Hello! This is a test.') # Fallback
            
            # Cria arquivo temporário
            temp_file = os.path.join(tempfile.gettempdir(), f"voice_preview_{os.getpid()}.mp3")
            
            # Gera áudio com a API do edge-tts
            async def generate_audio():
                communicate = edge_tts.Communicate(
                    preview_text,
                    self.voice,
                    rate=self.rate,
                    pitch=self.pitch
                )
                await communicate.save(temp_file)

            asyncio.run(generate_audio())
            
            if os.path.exists(temp_file):
                self.preview_ready.emit(temp_file)
            else:
                self.error_occurred.emit("Falha ao gerar preview")
                
        except Exception as e:
            self.error_occurred.emit(f"Erro: {str(e)}")

class ProcessingThread(QThread):
    progress_updated = pyqtSignal(str)
    chunk_progress = pyqtSignal(int, int)
    finished = pyqtSignal(bool, str) # Emite (sucesso, caminho_do_audio)

    def __init__(self, script_text, voice, rate, pitch, language, parent=None): # Adiciona 'language'
        super().__init__(parent)
        self.script_text = script_text
        self.voice = voice
        self.rate = rate
        self.pitch = pitch
        self.language = language # Armazena o idioma

    def run(self):
        try:
            # 1. Verifica se o texto não está vazio
            if not self.script_text:
                self.progress_updated.emit("Nenhum texto fornecido!")
                self.finished.emit(False, "")
                return

            # A verificação do edge-tts foi removida pois agora usamos a API diretamente.
            # Se houver um problema, ele será capturado durante a execução.

            self.progress_updated.emit("Iniciando processamento do roteiro...")

            # 3. Processa o texto e gera o áudio em um arquivo temporário
            # A função process_text retornará o caminho para o arquivo de áudio ou uma mensagem de erro
            final_audio_path, error_message = tts.process_text(
                self.script_text,
                self.voice,
                self.rate,
                self.pitch,
                self.language, # Passa o idioma
                progress_callback=self.chunk_progress.emit
            )

            if final_audio_path:
                self.progress_updated.emit("✓ Roteiro processado com sucesso!")
                self.finished.emit(True, final_audio_path)
            else:
                self.progress_updated.emit(f"✗ Erro ao processar: {error_message}")
                self.finished.emit(False, "")

        except Exception as e:
            self.progress_updated.emit(f"Erro inesperado no processamento: {str(e)}")
            self.finished.emit(False, "")

class CompactTextToSpeechGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.voices = []
        self.all_voices_display = []  # Armazena todas as vozes com marcadores
        self.presets = self.load_presets()
        self.temp_audio_file = "" # Armazena o caminho do arquivo de áudio gerado
        self.processing_queue = []
        self.is_processing_queue = False
        self.processing_start_time = 0
        # self.player = None
        # self.audio_output = None
        self.init_ui()
        self.load_voices()
    
    def load_presets(self):
        try:
            if os.path.exists(PRESETS_FILE):
                with open(PRESETS_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return []
        except FileNotFoundError:
            # É normal o arquivo não existir na primeira execução
            return []
        except json.JSONDecodeError as e:
            QMessageBox.warning(self, "Erro", f"Erro ao ler arquivo de favoritos (JSON inválido): {e}")
            return []
        except Exception as e:
            QMessageBox.warning(self, "Erro", f"Erro inesperado ao carregar favoritos: {e}")
            return []
    
    def save_presets(self):
        try:
            # Garante que o diretório exista
            os.makedirs(os.path.dirname(PRESETS_FILE), exist_ok=True)
            with open(PRESETS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.presets, f, ensure_ascii=False, indent=2)
                f.flush()  # Força a escrita no disco
                os.fsync(f.fileno()) # Garante que os dados sejam gravados no disco
        except Exception as e:
            QMessageBox.warning(self, "Erro", f"Erro ao salvar favoritos: {e}")
    
    def init_ui(self):
        self.setWindowTitle("Text to Speech Converter")
        palette = self.palette()
        palette.setColor(palette.ColorRole.Window, QColor("#1E1E1E"))
        self.setPalette(palette)
        self.setGeometry(100, 100, 700, 600)
        
        # Define o ícone da aplicação
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "img", "logo.png")
        if os.path.exists(logo_path):
            self.setWindowIcon(QIcon(logo_path))

        self.setStyleSheet("""
            QMainWindow {
                background-color: #1E1E1E;
            }
            QWidget {
                background-color: #1E1E1E; /* Fundo escuro para widgets gerais */
            }
            QLabel {
                color: #E8E8E8;
                font-size: 14px;
                font-family: 'Segoe UI';
                background-color: transparent;
            }
            QGroupBox {
                font-family: 'Segoe UI';
                font-size: 16px;
                font-weight: bold;
                color: #FFD700;
                border: 1px solid #FFD700;
                border-radius: 8px;
                margin-top: 10px;
                background-color: #2D2D30;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 15px;
                padding: 0 5px;
            }
            QTextEdit, QLineEdit, QComboBox {
                background-color: #252526;
                color: #E8E8E8;
                border: 1px solid #444;
                border-radius: 5px;
                padding: 8px;
                font-size: 14px;
            }
            QTextEdit:focus, QLineEdit:focus, QComboBox:focus {
                border: 1px solid #FFD700;
            }
            QComboBox QAbstractItemView {
                background-color: #252526;
                color: #E8E8E8;
                selection-background-color: #444;
                border: 1px solid #FFD700;
            }
            QListWidget {
                background-color: #252526;
                color: #E8E8E8;
                border: 1px solid #444;
                border-radius: 5px;
            }
            QListWidget::item:selected {
                background-color: #444;
            }
            QScrollArea {
                border: none;
            }
            QScrollBar:vertical {
                border: none;
                background: #252526;
                width: 10px;
                margin: 0px 0px 0px 0px;
            }
            QScrollBar::handle:vertical {
                background: #555;
                min-height: 20px;
                border-radius: 5px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QProgressBar {
                border: 1px solid #444;
                border-radius: 5px;
                text-align: center;
                background-color: #252526;
                color: #E8E8E8;
                height: 18px;
            }
            QProgressBar::chunk {
                background-color: #FFD700;
                border-radius: 5px;
            }
        """)

        # Scroll Area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        self.setCentralWidget(scroll_area)
        scroll_area.setStyleSheet("QScrollArea { background-color: #1E1E1E; border: none; }")

        # Conteúdo principal dentro da scroll area
        main_content_widget = QWidget()
        scroll_area.setWidget(main_content_widget)
        main_content_widget.setStyleSheet("QWidget { background-color: #1E1E1E; }")
        
        main_layout = QVBoxLayout(main_content_widget)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Logo e Títulos
        header_layout = QVBoxLayout()
        header_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        logo_label = QLabel()
        if os.path.exists(logo_path):
            pixmap = QPixmap(logo_path)
            logo_label.setPixmap(pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(logo_label)

        title_label = QLabel("Charles Networking")
        title_label.setStyleSheet("font-size: 26px; font-weight: bold; color: #FFD700; font-family: 'Verdana';")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(title_label)

        subtitle_label = QLabel("Gerador de Áudio")
        subtitle_label.setStyleSheet("font-size: 36px; font-weight: bold; color: #FFD700; font-family: 'Verdana'; margin-bottom: 10px;")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header_layout.addWidget(subtitle_label)

        main_layout.addLayout(header_layout)
        
        # Roteiro e Voz
        config_group = QGroupBox("Roteiro e Voz")
        config_layout = QVBoxLayout(config_group)
        config_layout.setSpacing(8)

        # Campo para colar o roteiro
        config_layout.addWidget(QLabel("Cole seu roteiro abaixo:"))
        self.script_input = QTextEdit()
        self.script_input.setPlaceholderText("Crie roteiros profissionais e envolventes para seus vídeos, podcasts e conteúdos digitais...")
        self.script_input.setMinimumHeight(150)
        config_layout.addWidget(self.script_input)

        # Busca de voz
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("🔍 Buscar:"))
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Digite para buscar (ex: brasil, neural, feminino, antonio...)")
        self.search_input.textChanged.connect(self.filter_voices)
        search_layout.addWidget(self.search_input, 1)
        config_layout.addLayout(search_layout)
        
        # Seletor de Idioma
        language_layout = QHBoxLayout()
        language_layout.addWidget(QLabel("Idioma do Roteiro:"))
        self.language_combo = QComboBox()
        self.language_combo.addItems([
            "Detectar Automaticamente",
            "Português (Brasil) - pt-BR",
            "Português (Portugal) - pt-PT",
            "Inglês (Estados Unidos) - en-US",
            "Espanhol (Espanha) - es-ES",
            "Francês (França) - fr-FR",
            "Alemão (Alemanha) - de-DE",
            "Italiano (Itália) - it-IT",
            "Chinês (Simplificado) - zh-CN",
            "Japonês (Japão) - ja-JP",
            "Coreano (Coreia) - ko-KR",
            "Russo (Rússia) - ru-RU",
            "Árabe (Arábia Saudita) - ar-SA"
        ])
        self.language_combo.setCurrentText("Português (Brasil) - pt-BR") # Define um padrão
        self.language_combo.currentIndexChanged.connect(self.filter_voices)  # Conecta o filtro
        language_layout.addWidget(self.language_combo)
        config_layout.addLayout(language_layout)

        # Voz
        voice_layout = QHBoxLayout()
        voice_layout.addWidget(QLabel("Voz:"))
        self.voice_combo = QComboBox()
        voice_layout.addWidget(self.voice_combo, 1)
        
        # Botão de preview
        preview_btn = QPushButton("▶️ Testar Voz")
        preview_btn.setStyleSheet(self.get_button_style())
        preview_btn.setToolTip("Ouvir preview da voz selecionada")
        preview_btn.clicked.connect(self.preview_voice)
        voice_layout.addWidget(preview_btn)
        
        config_layout.addLayout(voice_layout)

        # Aviso sobre vozes multilíngues
        multilingual_warning_label = QLabel(
            "⚠️ Vozes com o ícone 🌎 (Multilíngue) podem misturar idiomas em textos longos. "
            "Para narrações em um único idioma, prefira vozes específicas (ex: pt-BR)."
        )
        multilingual_warning_label.setStyleSheet(
            "font-style: italic; color: #FFD700; font-size: 12px; background-color: #2D2D30; "
            "border: 1px solid #444; border-radius: 5px; padding: 5px;"
        )
        multilingual_warning_label.setWordWrap(True)
        config_layout.addWidget(multilingual_warning_label)
        
        # Opções Avançadas (Tom e Ritmo)
        advanced_group = QGroupBox("Opções Avançadas")
        advanced_layout = QVBoxLayout(advanced_group)
        advanced_layout.setSpacing(8)

        # Tom Vocal (Pitch)
        pitch_layout = QHBoxLayout()
        pitch_layout.addWidget(QLabel("Tom Vocal:"))
        self.pitch_combo = QComboBox()
        self.pitch_combo.addItems(["Padrão", "Extra Baixo", "Baixo", "Médio", "Alto", "Extra Alto"])
        self.pitch_combo.setCurrentText("Médio")
        pitch_layout.addWidget(self.pitch_combo)
        advanced_layout.addLayout(pitch_layout)

        # Ritmo (Rate)
        rate_layout = QVBoxLayout()
        rate_label_layout = QHBoxLayout()
        rate_label_layout.addWidget(QLabel("Ritmo:"))
        self.rate_label = QLabel("+0%")
        self.rate_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        rate_label_layout.addWidget(self.rate_label)
        rate_layout.addLayout(rate_label_layout)
        
        self.rate_slider = QSlider(Qt.Orientation.Horizontal)
        self.rate_slider.setRange(-50, 100) # Corresponde a -50% to +100%
        self.rate_slider.setValue(0) # Padrão
        self.rate_slider.valueChanged.connect(self.update_rate_label)
        rate_layout.addWidget(self.rate_slider)
        advanced_layout.addLayout(rate_layout)

        # Info Pós-processamento
        processing_info_label = QLabel("Qualidade de áudio 'Estúdio CN' aplicada por padrão.")
        processing_info_label.setStyleSheet("font-style: italic; color: #AAA; font-size: 12px;")
        processing_info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        advanced_layout.addWidget(processing_info_label)
        
        config_layout.addWidget(advanced_group)

        main_layout.addWidget(config_group)
        
        # Presets
        presets_group = QGroupBox("⭐ Favoritas")
        presets_layout = QVBoxLayout(presets_group)
        presets_layout.setSpacing(5)
        
        self.presets_list = QListWidget()
        self.presets_list.setMaximumHeight(80)
        self.presets_list.itemDoubleClicked.connect(self.load_preset_voice)
        presets_layout.addWidget(self.presets_list)
        
        preset_btns = QHBoxLayout()
        add_btn = QPushButton("➕ Adicionar")
        add_btn.setStyleSheet(self.get_button_style())
        add_btn.clicked.connect(self.add_preset)
        remove_btn = QPushButton("🗑️ Remover")
        remove_btn.setStyleSheet(self.get_button_style())
        remove_btn.clicked.connect(self.remove_preset)
        preset_btns.addWidget(add_btn)
        preset_btns.addWidget(remove_btn)
        presets_layout.addLayout(preset_btns)
        
        main_layout.addWidget(presets_group)
        self.update_presets_list()

        # Fila de Processamento
        queue_group = QGroupBox("Fila de Processamento")
        queue_layout = QVBoxLayout(queue_group)
        queue_layout.setSpacing(5)

        self.queue_list = QListWidget()
        self.queue_list.setMaximumHeight(100)
        queue_layout.addWidget(self.queue_list)

        queue_btns_layout = QHBoxLayout()
        self.add_to_queue_btn = QPushButton("➕ Adicionar à Fila")
        self.add_to_queue_btn.setStyleSheet(self.get_button_style())
        self.add_to_queue_btn.clicked.connect(self.add_to_queue)
        
        self.clear_queue_btn = QPushButton("🧹 Limpar Fila")
        self.clear_queue_btn.setStyleSheet(self.get_button_style())
        self.clear_queue_btn.clicked.connect(self.clear_queue)

        queue_btns_layout.addWidget(self.add_to_queue_btn)
        queue_btns_layout.addWidget(self.clear_queue_btn)
        queue_layout.addLayout(queue_btns_layout)

        main_layout.addWidget(queue_group)
        
        # Processamento
        self.start_btn = QPushButton("🚀 Processar Fila")
        self.start_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFD700;
                color: #211E1C;
                border: none;
                border-radius: 8px;
                padding: 12px;
                font-size: 16px;
                font-weight: bold;
                font-family: 'Segoe UI';
            }
            QPushButton:hover {
                background-color: #FFC700;
            }
            QPushButton:disabled {
                background-color: #555;
                color: #888;
            }
        """)
        self.start_btn.clicked.connect(self.start_queue_processing)
        main_layout.addWidget(self.start_btn)
        
        # Log
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMaximumHeight(120)
        self.log_output.setStyleSheet("font-family: 'Courier New'; font-size: 12px;")
        main_layout.addWidget(self.log_output)
        
        # Progress
        progress_layout = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        progress_layout.addWidget(self.progress_bar, 1)

        self.speed_label = QLabel("Velocidade: -- p/s")
        self.speed_label.setVisible(False)
        progress_layout.addWidget(self.speed_label)

        main_layout.addLayout(progress_layout)
        
        # Player de Áudio
        # player_group = QGroupBox("▶️ Player de Áudio")
        # player_layout = QVBoxLayout(player_group)
        # player_layout.setSpacing(8)

        # self.audio_file_label = QLabel("Nenhum áudio carregado")
        # self.audio_file_label.setStyleSheet("font-style: italic; color: #AAA;")
        # player_layout.addWidget(self.audio_file_label)

        # player_controls_layout = QHBoxLayout()
        # self.play_pause_btn = QPushButton("Play")
        # self.play_pause_btn.setStyleSheet(self.get_button_style())
        # self.play_pause_btn.setEnabled(False)
        # self.play_pause_btn.clicked.connect(self.toggle_play_pause)
        
        # self.load_audio_btn = QPushButton("Carregar Áudio")
        # self.load_audio_btn.setStyleSheet(self.get_button_style())
        # self.load_audio_btn.clicked.connect(self.load_audio_file)

        # player_controls_layout.addWidget(self.play_pause_btn)
        # player_controls_layout.addWidget(self.load_audio_btn)
        # player_layout.addLayout(player_controls_layout)

        # time_layout = QHBoxLayout()
        # self.current_time_label = QLabel("00:00")
        # self.audio_slider = QSlider(Qt.Orientation.Horizontal)
        # self.audio_slider.setEnabled(False)
        # self.audio_slider.sliderMoved.connect(self.set_player_position)
        # self.duration_label = QLabel("00:00")
        # time_layout.addWidget(self.current_time_label)
        # time_layout.addWidget(self.audio_slider)
        # time_layout.addWidget(self.duration_label)
        # player_layout.addLayout(time_layout)

        # main_layout.addWidget(player_group)

        # Footer
        footer = QLabel("✨ Powered by AI ✨")
        footer.setStyleSheet("font-size: 12px; color: #AAA; padding: 3px;")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(footer)

        # self.setup_player()
    
    
    def get_button_style(self):
        return """
            QPushButton {
                background-color: #444;
                color: #E8E8E8;
                border: 1px solid #555;
                border-radius: 5px;
                padding: 8px 12px;
                font-size: 13px;
                font-family: 'Segoe UI';
            }
            QPushButton:hover {
                background-color: #555;
                border-color: #FFD700;
            }
        """

    def update_rate_label(self, value):
        if value >= 0:
            self.rate_label.setText(f"+{value}%")
        else:
            self.rate_label.setText(f"{value}%")
    
    def load_voices(self):
        self.log_output.append("Carregando vozes...")
        self.voice_combo.clear()
        self.voice_combo.addItem("Carregando...")
        self.voice_combo.setEnabled(False)
        
        self.voice_thread = VoiceLoaderThread()
        self.voice_thread.voices_loaded.connect(self.on_voices_loaded)
        self.voice_thread.error_occurred.connect(self.on_voice_error)
        self.voice_thread.start()
    
    def get_language_name(self, voice_name):
        """Retorna o nome completo do idioma baseado no código - DETECÇÃO AUTOMÁTICA"""
        
        # Dicionário de códigos de idioma ISO 639-1
        language_codes = {
            'af': 'Africâner', 'am': 'Amárico', 'ar': 'Árabe', 'az': 'Azerbaijano',
            'bg': 'Búlgaro', 'bn': 'Bengali', 'bs': 'Bósnio', 'ca': 'Catalão',
            'cs': 'Tcheco', 'cy': 'Galês', 'da': 'Dinamarquês', 'de': 'Alemão',
            'el': 'Grego', 'en': 'Inglês', 'es': 'Espanhol', 'et': 'Estoniano',
            'eu': 'Basco', 'fa': 'Persa', 'fi': 'Finlandês', 'fil': 'Filipino',
            'fr': 'Francês', 'ga': 'Irlandês', 'gl': 'Galego', 'gu': 'Gujarati',
            'he': 'Hebraico', 'hi': 'Hindi', 'hr': 'Croata', 'hu': 'Húngaro',
            'hy': 'Armênio', 'id': 'Indonésio', 'is': 'Islandês', 'it': 'Italiano',
            'ja': 'Japonês', 'jv': 'Javanês', 'ka': 'Georgiano', 'kk': 'Cazaque',
            'km': 'Khmer', 'kn': 'Kannada', 'ko': 'Coreano', 'lo': 'Laociano',
            'lt': 'Lituano', 'lv': 'Letão', 'mk': 'Macedônio', 'ml': 'Malayalam',
            'mn': 'Mongol', 'mr': 'Marathi', 'ms': 'Malaio', 'mt': 'Maltês',
            'my': 'Birmanês', 'nb': 'Norueguês', 'ne': 'Nepalês', 'nl': 'Holandês',
            'pl': 'Polonês', 'ps': 'Pashto', 'pt': 'Português', 'ro': 'Romeno',
            'ru': 'Russo', 'si': 'Cingalês', 'sk': 'Eslovaco', 'sl': 'Esloveno',
            'so': 'Somali', 'sq': 'Albanês', 'sr': 'Sérvio', 'su': 'Sundanês',
            'sv': 'Sueco', 'sw': 'Suaíli', 'ta': 'Tâmil', 'te': 'Telugu',
            'th': 'Tailandês', 'tr': 'Turco', 'uk': 'Ucraniano', 'ur': 'Urdu',
            'uz': 'Uzbeque', 'vi': 'Vietnamita', 'zh': 'Chinês', 'zu': 'Zulu',
            'wuu': 'Wu', 'yue': 'Cantonês',
        }
        
        # Dicionário de códigos de país/região ISO 3166-1
        country_codes = {
            'AE': 'Emirados Árabes', 'AF': 'Afeganistão', 'AL': 'Albânia', 
            'AM': 'Armênia', 'AR': 'Argentina', 'AT': 'Áustria', 'AU': 'Austrália',
            'AZ': 'Azerbaijão', 'BA': 'Bósnia', 'BD': 'Bangladesh', 'BE': 'Bélgica',
            'BG': 'Bulgária', 'BR': 'Brasil', 'CA': 'Canadá', 'CH': 'Suíça',
            'CL': 'Chile', 'CN': 'China', 'CO': 'Colômbia', 'CR': 'Costa Rica',
            'CU': 'Cuba', 'CY': 'Chipre', 'CZ': 'Tchéquia', 'DE': 'Alemanha',
            'DK': 'Dinamarca', 'DO': 'Rep. Dominicana', 'DZ': 'Argélia', 
            'EC': 'Equador', 'EE': 'Estônia', 'EG': 'Egito', 'ES': 'Espanha',
            'ET': 'Etiópia', 'FI': 'Finlândia', 'FR': 'França', 'GB': 'Reino Unido',
            'GE': 'Geórgia', 'GR': 'Grécia', 'GT': 'Guatemala', 'HK': 'Hong Kong',
            'HN': 'Honduras', 'HR': 'Croácia', 'HU': 'Hungria', 'ID': 'Indonésia',
            'IE': 'Irlanda', 'IL': 'Israel', 'IN': 'Índia', 'IQ': 'Iraque',
            'IR': 'Irã', 'IS': 'Islândia', 'IT': 'Itália', 'JO': 'Jordânia',
            'JP': 'Japão', 'KE': 'Quênia', 'KH': 'Camboja', 'KR': 'Coreia',
            'KZ': 'Cazaquistão', 'LA': 'Laos', 'LB': 'Líbano', 'LK': 'Sri Lanka',
            'LT': 'Lituânia', 'LV': 'Letônia', 'LY': 'Líbia', 'MA': 'Marrocos',
            'MK': 'Macedônia', 'MM': 'Myanmar', 'MN': 'Mongólia', 'MX': 'México',
            'MY': 'Malásia', 'MT': 'Malta', 'NE': 'Níger', 'NG': 'Nigéria',
            'NI': 'Nicarágua', 'NL': 'Holanda', 'NO': 'Noruega', 'NP': 'Nepal',
            'NZ': 'Nova Zelândia', 'OM': 'Omã', 'PA': 'Panamá', 'PE': 'Peru',
            'PH': 'Filipinas', 'PK': 'Paquistão', 'PL': 'Polônia', 'PS': 'Palestina',
            'PT': 'Portugal', 'PY': 'Paraguai', 'QA': 'Qatar', 'RO': 'Romênia',
            'RS': 'Sérvia', 'RU': 'Rússia', 'SA': 'Arábia Saudita', 'SE': 'Suécia',
            'SG': 'Singapura', 'SI': 'Eslovênia', 'SK': 'Eslováquia', 'SO': 'Somália',
            'SY': 'Síria', 'TH': 'Tailândia', 'TN': 'Tunísia', 'TR': 'Turquia',
            'TW': 'Taiwan', 'TZ': 'Tanzânia', 'UA': 'Ucrânia', 'US': 'Estados Unidos',
            'UY': 'Uruguai', 'UZ': 'Uzbequistão', 'VE': 'Venezuela', 'VN': 'Vietnã',
            'YE': 'Iêmen', 'ZA': 'África do Sul', 'ZW': 'Zimbábue',
        }
        
        # Extrai o código do idioma do nome da voz (ex: pt-BR-FranciscaNeural → pt-BR)
        import re
        match = re.match(r'^([a-z]{2,3})-([A-Z]{2})', voice_name)
        
        if match:
            lang_code = match.group(1).lower()  # ex: pt, en, zh
            country_code = match.group(2).upper()  # ex: BR, US, CN
            
            # Busca nome do idioma
            language_name = language_codes.get(lang_code, None)
            
            if language_name:
                # Busca nome do país/região
                country_name = country_codes.get(country_code, None)
                
                if country_name:
                    # Combina idioma + país
                    return f"{language_name} ({country_name})"
                else:
                    # Só idioma (com código do país)
                    return f"{language_name} ({country_code})"
            else:
                # Código de idioma desconhecido
                return f"{lang_code.upper()}-{country_code}"
        
        return None
    
    def on_voices_loaded(self, voices):
        multilingual_voices, other_voices = self.sort_voices(voices)
        sorted_voices = multilingual_voices + other_voices
        self.voices = sorted_voices
        
        # Armazena todas as vozes com seus marcadores para busca
        self.all_voices_display = []
        for name, gender in sorted_voices:
            # Adiciona marcadores visuais
            markers = []
            name_lower = name.lower()
            
            # Obtém nome do idioma
            lang_name = self.get_language_name(name)
            if lang_name:
                markers.append(f"[{lang_name}]")
            
            # Marca Multilingual
            if 'multilingual' in name_lower:
                markers.append("🌎")
            
            # Monta o texto de exibição
            marker_str = " ".join(markers)
            if marker_str:
                display_text = f"{marker_str} {name} ({gender})"
            else:
                display_text = f"{name} ({gender})"
            
            self.all_voices_display.append((display_text, name, gender))
        
        # Popula o combo box
        self.populate_voice_combo(self.all_voices_display)
        self.voice_combo.setEnabled(True)
        
        self.log_output.append(f"✅ {len(voices)} vozes carregadas")
        self.log_output.append("🌎 = Multilingual | [Idioma] entre colchetes")
        
        # Find and select the first Brazilian voice
        first_br_index = -1
        for i in range(self.voice_combo.count()):
            voice_name = self.voice_combo.itemData(i)
            if voice_name and 'br' in voice_name.lower():
                first_br_index = i
                break
        
        if first_br_index != -1:
            self.voice_combo.setCurrentIndex(first_br_index)
        elif sorted_voices: # fallback to first voice
            self.voice_combo.setCurrentIndex(0)
    
    def populate_voice_combo(self, voices_list):
        """Popula o combo box com a lista de vozes, separando as multilíngues."""
        self.voice_combo.clear()
        
        multilingual_to_add = []
        others_to_add = []
        
        # voices_list is a list of (display_text, name, gender)
        for display_text, name, gender in voices_list:
            if "🌎" in display_text:
                multilingual_to_add.append((display_text, name))
            else:
                others_to_add.append((display_text, name))
        
        # Adiciona as vozes multilíngues
        for display_text, name in multilingual_to_add:
            self.voice_combo.addItem(display_text, name)
            
        # Adiciona um separador se necessário
        if multilingual_to_add and others_to_add:
            self.voice_combo.insertSeparator(self.voice_combo.count())
            
        # Adiciona as outras vozes
        for display_text, name in others_to_add:
            self.voice_combo.addItem(display_text, name)
    
    def filter_voices(self):
        """Filtra vozes baseado no idioma selecionado e no texto de busca."""
        search_text = self.search_input.text().lower().strip()
        
        # Obtém o código do idioma do seletor
        selected_language_display = self.language_combo.currentText()
        language_code_match = re.search(r'\- ([a-zA-Z]{2}\-[a-zA-Z]{2})', selected_language_display)
        
        lang_filter = ""
        if language_code_match:
            lang_filter = language_code_match.group(1).lower()
        
        # Se "Detectar Automaticamente" estiver selecionado, não filtra por idioma
        if "detectar" in selected_language_display.lower():
            lang_filter = ""

        # Filtra vozes pelo idioma
        voices_to_search = []
        if lang_filter:
            for display_text, name, gender in self.all_voices_display:
                # Inclui vozes que correspondem ao idioma ou são multilíngues
                if f"-{lang_filter.lower()}-" in name.lower() or "multilingual" in name.lower():
                    voices_to_search.append((display_text, name, gender))
        else:
            # Se "Detectar Automaticamente", mostra todas as vozes
            voices_to_search = self.all_voices_display

        # Filtra pelo texto de busca
        if not search_text:
            filtered = voices_to_search
        else:
            # Mapa de termos de busca para facilitar
            search_map = {
                'brasil': 'br', 'brazil': 'br', 'portugues': 'br', 'português': 'br',
                'ingles': 'en', 'inglês': 'en', 'english': 'en', 'us': 'en', 'eua': 'en',
                'espanhol': 'es', 'spanish': 'es', 'spain': 'es', 'espanha': 'es',
                'masculino': 'male', 'feminino': 'female', 'homem': 'male', 'mulher': 'female',
            }
            
            # Substitui termos conhecidos
            for key, value in search_map.items():
                if key in search_text:
                    search_text = search_text.replace(key, value)
            
            filtered = []
            for display_text, name, gender in voices_to_search:
                search_in = f"{display_text} {name} {gender}".lower()
                search_terms = search_text.split()
                if all(term in search_in for term in search_terms):
                    filtered.append((display_text, name, gender))

        # Atualiza combo box
        self.populate_voice_combo(filtered)
        
        # Log de resultados
        if filtered:
            if len(filtered) == 1:
                self.log_output.append(f"🔍 1 voz encontrada")
            else:
                self.log_output.append(f"🔍 {len(filtered)} vozes encontradas")
        else:
            self.log_output.append("🔍 Nenhuma voz encontrada")

    def sort_voices(self, voices):
        multilingual_voices = []
        other_voices = []
        
        for name, gender in voices:
            if 'multilingual' in name.lower():
                multilingual_voices.append((name, gender))
            else:
                other_voices.append((name, gender))
        
        br_voices = [v for v in other_voices if 'br' in v[0].lower()]
        other_non_br_voices = [v for v in other_voices if 'br' not in v[0].lower()]
        
        br_voices.sort(key=lambda x: x[0])
        other_non_br_voices.sort(key=lambda x: x[0])
        multilingual_voices.sort(key=lambda x: x[0])
        
        return multilingual_voices, br_voices + other_non_br_voices
    
    def on_voice_error(self, error):
        self.voice_combo.clear()
        self.voice_combo.addItem("Erro ao carregar vozes")
        self.voice_combo.setEnabled(False)
        self.log_output.append(f"❌ Erro: {error}")
        QMessageBox.critical(self, "Erro", f"Erro ao carregar vozes:\n{error}")
    
    def update_presets_list(self):
        self.presets_list.clear()
        for preset in self.presets:
            item = QListWidgetItem(f"⭐ {preset['name']}")
            item.setData(Qt.ItemDataRole.UserRole, preset)
            self.presets_list.addItem(item)
    
    def add_preset(self):
        if self.voice_combo.currentIndex() == -1:
            QMessageBox.warning(self, "Aviso", "Selecione uma voz primeiro!")
            return
        
        voice = self.voice_combo.currentData()
        voice_name = self.voice_combo.currentText()
        
        if not voice:
            return
        
        for preset in self.presets:
            if preset['voice'] == voice:
                QMessageBox.information(self, "Info", "Esta voz já está nos favoritos!")
                return
        
        name, ok = QInputDialog.getText(self, "Nome do Favorito", 
                                       "Digite um nome:",
                                       text=voice_name.split('(')[0].strip())
        
        if ok and name:
            self.presets.append({
                'name': name,
                'voice': voice,
                'full_name': voice_name
            })
            self.save_presets()
            self.update_presets_list()
            self.log_output.append(f"⭐ Adicionado: {name}")
    
    def remove_preset(self):
        current_item = self.presets_list.currentItem()
        if not current_item:
            QMessageBox.warning(self, "Aviso", "Selecione um favorito para remover!")
            return
        
        preset = current_item.data(Qt.ItemDataRole.UserRole)
        
        reply = QMessageBox.question(self, "Confirmar", 
                                    f"Remover '{preset['name']}'?",
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            self.presets.remove(preset)
            self.save_presets()
            self.update_presets_list()
            self.log_output.append(f"🗑️ Removido: {preset['name']}")
    
    def load_preset_voice(self, item):
        preset = item.data(Qt.ItemDataRole.UserRole)
        
        for i in range(self.voice_combo.count()):
            if self.voice_combo.itemData(i) == preset['voice']:
                self.voice_combo.setCurrentIndex(i)
                self.log_output.append(f"⭐ Carregado: {preset['name']}")
                break
    
    def add_to_queue(self):
        """Pede um nome de arquivo e adiciona o roteiro à fila."""
        script_text = self.script_input.toPlainText().strip()
        if not script_text:
            QMessageBox.warning(self, "Aviso", "O campo de roteiro está vazio!")
            return

        if self.voice_combo.currentIndex() == -1:
            QMessageBox.warning(self, "Aviso", "Selecione uma voz!")
            return

        voice = self.voice_combo.currentData()
        voice_name = self.voice_combo.currentText().split('(')[0].strip()

        if not voice:
            QMessageBox.warning(self, "Aviso", "Voz inválida selecionada!")
            return
        
        # Pop-up de confirmação para vozes multilíngues
        if "multilingual" in voice.lower():
            reply = QMessageBox.question(self, "Aviso de Voz Multilíngue",
                                         "Você selecionou uma voz multilíngue (🌎).\n\n"
                                         "Essas vozes podem misturar idiomas ou ter sotaques inesperados em textos longos. "
                                         "Para obter melhores resultados em um único idioma, recomendamos usar uma voz específica (ex: pt-BR).\n\n"
                                         "Deseja continuar com a voz multilíngue selecionada?",
                                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                         QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.No:
                self.log_output.append("Seleção de voz multilíngue cancelada pelo usuário.")
                return

        # Sugere um nome de arquivo baseado na voz e no texto
        suggested_filename = f"{voice_name}_{len(script_text.split())}_palavras"
        safe_filename = "".join(x for x in suggested_filename if x.isalnum() or x in " _-").strip()

        # Pede ao usuário para confirmar/editar o nome do arquivo
        file_name, ok = QInputDialog.getText(self, "Nome do Arquivo",
                                             "Digite o nome para o arquivo de áudio (sem .mp3):",
                                             text=safe_filename)

        if not ok or not file_name:
            self.log_output.append("Adição à fila cancelada.")
            return

        # Adiciona à estrutura de dados da fila
        # Obtém as configurações de tom e ritmo
        pitch_text = self.pitch_combo.currentText()
        pitch_map = {
            "Padrão": "+0Hz", "Extra Baixo": "-30Hz", "Baixo": "-15Hz",
            "Médio": "+0Hz", "Alto": "+15Hz", "Extra Alto": "+30Hz"
        }
        pitch = pitch_map.get(pitch_text, "+0Hz")

        rate_value = self.rate_slider.value()
        rate = f"+{rate_value}%" if rate_value >= 0 else f"{rate_value}%"
        
        # Obtém o idioma selecionado
        selected_language_display = self.language_combo.currentText()
        # Extrai o código do idioma (ex: "pt-BR")
        language_code_match = re.search(r'\- ([a-zA-Z]{2}\-[a-zA-Z]{2})$', selected_language_display)
        if language_code_match:
            language_code = language_code_match.group(1)
        else:
            language_code = "auto" # Ou um valor padrão/indicador para detecção automática
        
        # Adiciona à estrutura de dados da fila
        queue_item = {
            "text": script_text,
            "voice": voice,
            "display_name": f"{file_name} ({voice_name}) [{language_code}]",
            "output_filename": file_name.strip() + ".mp3",
            "rate": rate,
            "pitch": pitch,
            "language": language_code, # Adiciona o idioma à fila
        }
        self.processing_queue.append(queue_item)

        # Adiciona à lista visual
        self.queue_list.addItem(queue_item["display_name"])
        self.log_output.append(f"➕ Adicionado à fila: {queue_item['display_name']}")
        
        # Limpa o campo de texto para o próximo roteiro
        self.script_input.clear()

    def clear_queue(self):
        """Limpa a fila de processamento."""
        if self.is_processing_queue:
            QMessageBox.warning(self, "Aviso", "Não é possível limpar a fila durante o processamento.")
            return
        self.processing_queue.clear()
        self.queue_list.clear()
        self.log_output.append("🧹 Fila de processamento limpa.")

    def start_queue_processing(self):
        """Inicia o processamento da fila."""
        if not self.processing_queue:
            QMessageBox.information(self, "Fila Vazia", "Adicione itens à fila antes de processar.")
            return

        if self.is_processing_queue:
            QMessageBox.warning(self, "Em Andamento", "O processamento da fila já está em andamento.")
            return

        self.is_processing_queue = True
        self.start_btn.setEnabled(False)
        self.add_to_queue_btn.setEnabled(False)
        self.clear_queue_btn.setEnabled(False)
        self.start_btn.setText("🔄 Processando Fila...")
        
        self.log_output.clear()
        self.log_output.append(f"🚀 Iniciando processamento de {len(self.processing_queue)} item(ns) da fila...")

        self.processing_start_time = time.time()
        
        self.process_next_in_queue()

    def process_next_in_queue(self):
        """Processa o próximo item da fila."""
        if not self.processing_queue:
            self.log_output.append("\n✅ Fila concluída!")
            self.is_processing_queue = False
            self.start_btn.setEnabled(True)
            self.add_to_queue_btn.setEnabled(True)
            self.clear_queue_btn.setEnabled(True)
            self.start_btn.setText("🚀 Processar Fila")
            self.progress_bar.setVisible(False)
            self.speed_label.setVisible(False)
            return

        # Pega o próximo item sem removê-lo ainda
        item_to_process = self.processing_queue[0]
        
        # Atualiza a UI para indicar o item atual
        self.queue_list.setCurrentRow(0)
        self.log_output.append(f"\n▶️ Processando: {item_to_process['display_name']}")

        self.progress_bar.setVisible(True)
        self.speed_label.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("Gerando áudio... (0%)")
        self.speed_label.setText("Velocidade: -- p/s")
        
        self.processing_thread = ProcessingThread(
            item_to_process["text"],
            item_to_process["voice"],
            item_to_process["rate"],
            item_to_process["pitch"],
            item_to_process["language"] # Passa o idioma
        )
        self.processing_thread.chunk_progress.connect(self.update_generation_progress)
        self.processing_thread.progress_updated.connect(self.on_progress_update)
        self.processing_thread.finished.connect(self.on_processing_finished)
        self.processing_thread.start()

    def on_progress_update(self, message):
        self.log_output.append(message)
        cursor = self.log_output.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.log_output.setTextCursor(cursor)

    def on_processing_finished(self, success, audio_path):
        # Remove o item que acabou de ser processado
        processed_item = self.processing_queue.pop(0)
        self.queue_list.takeItem(0)

        if success and audio_path:
            self.log_output.append(f"✅ Concluído: {processed_item['display_name']}. Salvando...")
            self.temp_audio_file = audio_path
            
            # Pega o nome do arquivo do item da fila
            output_filename = processed_item["output_filename"]
            
            # Garante que o diretório 'output' exista
            # Em um executável PyInstaller, __file__ pode apontar para um local temporário.
            # sys.executable aponta para o caminho do executável principal.
            base_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
            output_dir = os.path.join(base_dir, "output")
            os.makedirs(output_dir, exist_ok=True)
            
            # Constrói o caminho final e salva
            final_path = os.path.join(output_dir, output_filename)
            self.save_final_audio(final_path)
        else:
            self.log_output.append(f"❌ Erro no processamento de: {processed_item['display_name']}")
            QMessageBox.warning(self, "Erro", f"Ocorreu um erro durante o processamento do item:\n{processed_item['display_name']}")

        # Se ainda estiver no modo de fila, processa o próximo
        if self.is_processing_queue:
            self.process_next_in_queue()
        else: # Finaliza se não estiver em modo fila
            self.start_btn.setEnabled(True)
            self.add_to_queue_btn.setEnabled(True)
            self.clear_queue_btn.setEnabled(True)
            self.start_btn.setText("🚀 Processar Fila")
            self.progress_bar.setVisible(False)
            self.speed_label.setVisible(False)

    def update_generation_progress(self, current, total):
        """Atualiza a barra de progresso e a velocidade durante a geração dos chunks."""
        if total > 0:
            percentage = int((current / total) * 100)
            self.progress_bar.setValue(percentage)
            self.progress_bar.setFormat(f"{percentage}% ({current}/{total} partes)")
            
            elapsed_time = time.time() - self.processing_start_time
            if elapsed_time > 0.5: # Evita divisão por zero e atualizações muito rápidas
                speed = current / elapsed_time
                self.speed_label.setText(f"Velocidade: {speed:.1f} p/s")

    def save_final_audio(self, final_path):
        """Move o arquivo de áudio temporário para o caminho final na pasta 'output'."""
        if not self.temp_audio_file or not os.path.exists(self.temp_audio_file):
            self.log_output.append("❌ Erro: Arquivo de áudio temporário não encontrado para salvar.")
            return
        
        try:
            import shutil
            shutil.move(self.temp_audio_file, final_path)
            self.log_output.append(f"✅ Áudio salvo com sucesso em: {final_path}")
        except Exception as e:
            self.log_output.append(f"❌ Erro ao salvar o arquivo: {e}")
            QMessageBox.critical(self, "Erro ao Salvar", f"Não foi possível salvar o arquivo em {final_path}:\n{e}")
            # Tenta remover o arquivo temporário mesmo em caso de falha ao mover
            if os.path.exists(self.temp_audio_file):
                os.remove(self.temp_audio_file)
        
        self.temp_audio_file = "" # Limpa a referência
    
    def preview_voice(self):
        """Gera e reproduz um preview da voz selecionada"""
        if self.voice_combo.currentIndex() == -1:
            QMessageBox.warning(self, "Aviso", "Selecione uma voz primeiro!")
            return
        
        voice = self.voice_combo.currentData()
        if not voice:
            QMessageBox.warning(self, "Aviso", "Voz inválida!")
            return

        # Obtém as configurações de tom e ritmo
        pitch_text = self.pitch_combo.currentText()
        pitch_map = {
            "Padrão": "+0Hz", "Extra Baixo": "-30Hz", "Baixo": "-15Hz",
            "Médio": "+0Hz", "Alto": "+15Hz", "Extra Alto": "+30Hz"
        }
        pitch = pitch_map.get(pitch_text, "+0Hz")

        rate_value = self.rate_slider.value()
        rate = f"+{rate_value}%" if rate_value >= 0 else f"{rate_value}%"
        
        # Obtém o idioma selecionado para o preview
        selected_language_display = self.language_combo.currentText()
        language_code_match = re.search(r'\- ([a-zA-Z]{2}\-[a-zA-Z]{2})$', selected_language_display)
        if language_code_match:
            language_code = language_code_match.group(1)
        else:
            language_code = "auto"

        self.log_output.append(f"🎤 Gerando preview de: {voice} (Tom: {pitch_text}, Ritmo: {rate}, Idioma: {language_code})...")
        
        # Inicia thread de preview
        self.preview_thread = PreviewThread(voice, rate, pitch, language_code) # Passa o idioma
        self.preview_thread.preview_ready.connect(self.play_preview)
        self.preview_thread.error_occurred.connect(self.on_preview_error)
        self.preview_thread.start()
    
    def play_preview(self, audio_file):
        """Reproduz o áudio de preview"""
        try:
            import os
            
            self.log_output.append("▶️ Reproduzindo preview...")
            
            # Reproduz o áudio usando o player padrão do sistema
            if os.name == 'nt':  # Windows
                os.startfile(audio_file)
            elif os.name == 'posix':  # Linux/Mac
                import subprocess
                if sys.platform == 'darwin':  # Mac
                    subprocess.run(['open', audio_file])
                else:  # Linux
                    subprocess.run(['xdg-open', audio_file])
            
            self.log_output.append("✅ Preview reproduzido!")
            
        except Exception as e:
            self.log_output.append(f"❌ Erro ao reproduzir: {e}")
    
    def on_preview_error(self, error):
        """Callback quando há erro no preview"""
        self.log_output.append(f"❌ Erro no preview: {error}")
        QMessageBox.warning(self, "Erro", f"Erro ao gerar preview:\n{error}")

    # def setup_player(self):
    #     self.player = QMediaPlayer()
    #     self.audio_output = QAudioOutput()
    #     self.player.setAudioOutput(self.audio_output)

    #     self.player.positionChanged.connect(self.update_slider_position)
    #     self.player.durationChanged.connect(self.update_duration)
    #     self.player.mediaStatusChanged.connect(self.handle_media_status)

    # def load_audio_file(self):
    #     output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
    #     os.makedirs(output_dir, exist_ok=True)
        
    #     file_path, _ = QFileDialog.getOpenFileName(self, "Carregar Arquivo de Áudio",
    #                                                output_dir,
    #                                                "Arquivos de Áudio (*.mp3)")
        
    #     if file_path:
    #         self.player.setSource(QUrl.fromLocalFile(file_path))
    #         self.audio_file_label.setText(os.path.basename(file_path))
    #         self.play_pause_btn.setEnabled(True)
    #         self.audio_slider.setEnabled(True)
    #         self.play_pause_btn.setText("Play")

    # def toggle_play_pause(self):
    #     if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
    #         self.player.pause()
    #         self.play_pause_btn.setText("Play")
    #     else:
    #         self.player.play()
    #         self.play_pause_btn.setText("Pause")

    # def update_slider_position(self, position):
    #     self.audio_slider.setValue(position)
    #     self.current_time_label.setText(self.format_time(position))

    # def update_duration(self, duration):
    #     self.audio_slider.setRange(0, duration)
    #     self.duration_label.setText(self.format_time(duration))

    # def set_player_position(self, position):
    #     self.player.setPosition(position)

    # def handle_media_status(self, status):
    #     if status == QMediaPlayer.MediaStatus.EndOfMedia:
    #         self.play_pause_btn.setText("Play")
    #         self.player.setPosition(0)

    # def format_time(self, ms):
    #     seconds = int((ms / 1000) % 60)
    #     minutes = int((ms / (1000 * 60)) % 60)
    #     return f"{minutes:02d}:{seconds:02d}"

