import os
import subprocess
from pathlib import Path
import logging

# Configura o logger para este módulo
logger = logging.getLogger(__name__)

# Define flags para subprocessos no Windows para evitar a criação de janelas de console
subprocess_flags = 0
if os.name == 'nt':
    subprocess_flags = subprocess.CREATE_NO_WINDOW

class TTSAudioProcessor:
    """
    Processador de áudio com um preset de alta qualidade para vozes TTS.
    """
    
    def __init__(self, ffmpeg_path="ffmpeg"):
        self.ffmpeg_path = ffmpeg_path
        logger.debug(f"TTSAudioProcessor inicializado com ffmpeg_path: {self.ffmpeg_path}")

    def _executar_processamento(self, arquivo_entrada, arquivo_saida, cadeia_filtros, bitrate):
        """Executa o comando FFmpeg com a cadeia de filtros fornecida."""
        logger.debug(f"Iniciando _executar_processamento para {arquivo_entrada} -> {arquivo_saida}")
        if arquivo_saida is None:
            entrada_path = Path(arquivo_entrada)
            arquivo_saida = entrada_path.parent / f"{entrada_path.stem}_processado.mp3"
            logger.debug(f"arquivo_saida não especificado, usando padrão: {arquivo_saida}")

        # Verifica se o FFmpeg está disponível
        try:
            subprocess.run([self.ffmpeg_path, "-version"], check=True, capture_output=True, creationflags=subprocess_flags)
            logger.debug("FFmpeg verificado com sucesso.")
        except FileNotFoundError:
            error_msg = (
                "ERRO: FFmpeg não encontrado! Por favor, instale o FFmpeg e adicione-o ao PATH do sistema."
                "\nInstruções: https://ffmpeg.org/download.html"
            )
            logger.critical(error_msg)
            raise RuntimeError(error_msg)
        except subprocess.CalledProcessError as e:
            error_msg = f"ERRO: FFmpeg encontrado, mas falhou ao executar: {e.stderr}"
            logger.critical(error_msg)
            raise RuntimeError(error_msg)

        comando = [
            self.ffmpeg_path,
            "-i", str(arquivo_entrada),
            "-af", cadeia_filtros,
            "-ar", "44100",
            "-ac", "1",
            "-b:a", bitrate,
            "-codec:a", "libmp3lame",
            "-q:a", "2",
            "-y",
            str(arquivo_saida)
        ]
        logger.debug(f"Comando FFmpeg a ser executado: {' '.join(comando)}")
        
        try:
            resultado = subprocess.run(
                comando,
                capture_output=True,
                text=True,
                check=True,
                creationflags=subprocess_flags
            )
            # Verifica se o arquivo de saída foi criado e não está vazio
            if os.path.exists(arquivo_saida) and os.path.getsize(arquivo_saida) > 0:
                logger.info(f"✓ Áudio processado com o preset 'Estúdio CN': {arquivo_saida}")
                logger.debug(f"FFmpeg STDOUT: {resultado.stdout}")
                logger.debug(f"FFmpeg STDERR: {resultado.stderr}")
                return str(arquivo_saida)
            else:
                error_msg = f"✗ Falha ao criar ou arquivo de saída vazio: {arquivo_saida}"
                logger.error(error_msg)
                raise RuntimeError(error_msg)
            
        except subprocess.CalledProcessError as e:
            error_details = e.stderr.strip()
            logger.error(f"✗ Erro ao processar áudio com FFmpeg:")
            logger.error(f"  Comando: {' '.join(comando)}")
            logger.error(f"  Erro: {error_details}")
            raise RuntimeError(f"Erro no FFmpeg: {error_details}") from e

    def processar_preset_estudio_cn(self, arquivo_entrada, arquivo_saida=None):
        """
        PRESET "ESTÚDIO CN": Som aveludado, com agudos controlados e sem "tinido".
        Baseado no preset "Calmo" que você aprovou.
        """
        filtros = [
            "acompressor=threshold=-20dB:ratio=2.5:attack=10:release=60:makeup=1dB",
            "equalizer=f=4000:width_type=q:width=1.5:g=-3", # Corte nos médios-agudos
            "equalizer=f=8000:width_type=q:width=2:g=-5",   # Corte forte nos agudos
            "lowpass=f=12000",                             # Filtro para remover o "ar" excessivo
            "deesser=i=0.4:m=0.5:f=0.5:s=o",
            "loudnorm=I=-16:TP=-1.5:LRA=11",
            "highpass=f=75"
        ]
        cadeia = ",".join(filtros)
        return self._executar_processamento(arquivo_entrada, arquivo_saida, cadeia, "160k")
