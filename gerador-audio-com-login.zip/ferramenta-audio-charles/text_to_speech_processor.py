import os
import sys
import subprocess
import re
import shutil
import tempfile
from pathlib import Path
import asyncio
import edge_tts
from audio_processor import TTSAudioProcessor
import logging

# Configura o logger para este módulo
logger = logging.getLogger(__name__)

# Define flags para subprocessos no Windows para evitar a criação de janelas de console
subprocess_flags = 0
if os.name == 'nt':
    subprocess_flags = subprocess.CREATE_NO_WINDOW

# ============================================================================
# DICIONÁRIO DE PALAVRAS PROBLEMÁTICAS
# ============================================================================
# Palavras em outros idiomas que frequentemente causam mudança de voz
# Substitua por equivalentes no idioma desejado ou por pronúncia fonética

PROBLEMATIC_WORDS = {
    "pt-BR": {
        # Palavras em inglês que devem ser faladas em português
        "hello": "alô",
        "world": "mundo",
        "test": "teste",
        "email": "i-méil",
        "download": "daunlôud",
        "software": "sóftuer",
        "hardware": "rárduér",
        "update": "atualização",
        "upgrade": "aprimoramento",
        
        # Palavras em português que podem ser confundidas com espanhol
        # Edge TTS às vezes confunde essas terminações
        "recuperem": "recuperem",  # Força pronúncia PT-BR
        "protegidas": "protegidas",
        "marinhas": "marinhas",
        "permitem": "permitem",
        "população": "população",
        
        # Adicione mais conforme necessário
    },
    "en-US": {
        # Palavras em português que aparecem em textos ingleses
        "olá": "hello",
        "obrigado": "thank you",
        # Adicione mais conforme necessário
    },
    # Adicione outros idiomas conforme necessário
}

def replace_problematic_words(text, language_code):
    """
    Substitui palavras estrangeiras conhecidas por equivalentes no idioma alvo.
    
    Args:
        text: Texto a ser processado
        language_code: Código do idioma alvo
    
    Returns:
        Texto com substituições aplicadas
    """
    if language_code not in PROBLEMATIC_WORDS:
        return text
    
    replacements = PROBLEMATIC_WORDS[language_code]
    
    # Substitui palavras (case-insensitive, preserva capitalização)
    for foreign_word, native_word in replacements.items():
        # Substitui a palavra inteira (não dentro de outras palavras)
        pattern = r'\b' + re.escape(foreign_word) + r'\b'
        text = re.sub(pattern, native_word, text, flags=re.IGNORECASE)
    
    return text

# ============================================================================
# MAPEAMENTO DE VOZES POR IDIOMA - EVITA MISTURA DE IDIOMAS
# ============================================================================
# Use vozes NATIVAS do idioma, NÃO as multilinguais
# As vozes multilinguais tendem a misturar idiomas automaticamente
# IMPORTANTE: As primeiras vozes da lista são as MAIS ESTÁVEIS (evitam mistura de idiomas)

VOICE_MAPPING = {
    # Português Brasil - ORDEM POR ESTABILIDADE
    "pt-BR": {
        "female": ["pt-BR-FranciscaNeural", "pt-BR-BrendaNeural", "pt-BR-ThalitaNeural"],
        "male": ["pt-BR-AntonioNeural", "pt-BR-DonatoNeural", "pt-BR-FabioNeural"],
    },
    # Português Portugal
    "pt-PT": {
        "female": ["pt-PT-RaquelNeural", "pt-PT-FernandaNeural"],
        "male": ["pt-PT-DuarteNeural"],
    },
    # Inglês USA
    "en-US": {
        "female": ["en-US-JennyNeural", "en-US-AriaNeural", "en-US-SaraNeural"],
        "male": ["en-US-GuyNeural", "en-US-ChristopherNeural", "en-US-EricNeural"],
    },
    # Inglês UK
    "en-GB": {
        "female": ["en-GB-SoniaNeural", "en-GB-LibbyNeural", "en-GB-MiaNeural"],
        "male": ["en-GB-RyanNeural", "en-GB-ThomasNeural"],
    },
    # Espanhol Espanha
    "es-ES": {
        "female": ["es-ES-ElviraNeural", "es-ES-AbrilNeural"],
        "male": ["es-ES-AlvaroNeural", "es-ES-ArnauNeural"],
    },
    # Espanhol México
    "es-MX": {
        "female": ["es-MX-DaliaNeural", "es-MX-BeatrizNeural"],
        "male": ["es-MX-JorgeNeural", "es-MX-LibertoNeural"],
    },
    # Francês
    "fr-FR": {
        "female": ["fr-FR-DeniseNeural", "fr-FR-BrigitteNeural", "fr-FR-CelesteNeural"],
        "male": ["fr-FR-HenriNeural", "fr-FR-AlainNeural", "fr-FR-ClaudeNeural"],
    },
    # Alemão
    "de-DE": {
        "female": ["de-DE-KatjaNeural", "de-DE-AmalaNeural", "de-DE-GiselaNeural"],
        "male": ["de-DE-ConradNeural", "de-DE-KasperNeural", "de-DE-KillianNeural"],
    },
    # Italiano
    "it-IT": {
        "female": ["it-IT-ElsaNeural", "it-IT-IsabellaNeural", "it-IT-FiammaNeural"],
        "male": ["it-IT-DiegoNeural", "it-IT-BenignoNeural", "it-IT-CalimeroNeural"],
    },
    # Japonês
    "ja-JP": {
        "female": ["ja-JP-NanamiNeural", "ja-JP-AoiNeural", "ja-JP-MayuNeural"],
        "male": ["ja-JP-KeitaNeural", "ja-JP-DaichiNeural", "ja-JP-NaokiNeural"],
    },
    # Coreano
    "ko-KR": {
        "female": ["ko-KR-SunHiNeural", "ko-KR-JiMinNeural", "ko-KR-SoonBokNeural"],
        "male": ["ko-KR-InJoonNeural", "ko-KR-BongJinNeural", "ko-KR-GookMinNeural"],
    },
    # Chinês Simplificado
    "zh-CN": {
        "female": ["zh-CN-XiaoxiaoNeural", "zh-CN-XiaoyiNeural", "zh-CN-XiaohanNeural"],
        "male": ["zh-CN-YunxiNeural", "zh-CN-YunjianNeural", "zh-CN-YunyangNeural"],
    },
    # Russo
    "ru-RU": {
        "female": ["ru-RU-SvetlanaNeural", "ru-RU-DariyaNeural"],
        "male": ["ru-RU-DmitryNeural"],
    },
    # Árabe
    "ar-SA": {
        "female": ["ar-SA-ZariyahNeural"],
        "male": ["ar-SA-HamedNeural"],
    },
    # Hindi
    "hi-IN": {
        "female": ["hi-IN-SwaraNeural"],
        "male": ["hi-IN-MadhurNeural"],
    },
}

def get_voice_for_language(language_code, preferred_gender="female", voice_name=None):
    """
    Retorna a melhor voz para o idioma especificado.
    
    Args:
        language_code: Código do idioma (ex: pt-BR, en-US)
        preferred_gender: "female" ou "male"
        voice_name: Nome específico da voz (opcional, sobrescreve a seleção automática)
    
    Returns:
        Nome da voz a ser usada
    """
    # Se o usuário especificou uma voz, usa ela
    if voice_name:
        logger.info(f"Usando voz especificada pelo usuário: {voice_name}")
        return voice_name
    
    # Busca vozes nativas do idioma
    if language_code in VOICE_MAPPING:
        voices = VOICE_MAPPING[language_code].get(preferred_gender, [])
        if voices:
            selected_voice = voices[0]  # Usa a primeira voz da lista
            logger.info(f"Voz selecionada para {language_code} ({preferred_gender}): {selected_voice}")
            return selected_voice
    
    # Fallback: tenta encontrar qualquer voz do idioma
    logger.warning(f"Idioma {language_code} não encontrado no mapeamento, usando fallback")
    return f"{language_code}-Neural"  # Fallback genérico

def force_language_pronunciation(text, language_code):
    """
    Força a pronúncia correta adicionando pausas e reformatando o texto.
    Essa é a solução DEFINITIVA para problemas de mistura de idiomas.
    
    Args:
        text: Texto a ser processado
        language_code: Código do idioma
    
    Returns:
        Texto formatado para forçar pronúncia correta
    """
    if language_code == "pt-BR":
        # Adiciona vírgulas estratégicas para forçar pausa e resetar contexto
        # Isso ajuda o TTS a "recalibrar" e manter o idioma correto
        
        # Padrões problemáticos conhecidos
        patterns = [
            # Verbos no subjuntivo que podem ser confundidos com espanhol
            (r'\b(recuperem|desenvolvam|permitam|protejam)\b', r', \1,'),
            
            # Palavras terminadas em -em que podem ser confundidas
            (r'\b(\w+em)\s+(que|de|para|com)\b', r'\1, \2'),
        ]
        
        for pattern, replacement in patterns:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        
        # Remove vírgulas duplicadas
        text = re.sub(r',\s*,', ',', text)
        
        # Remove vírgulas no início/fim
        text = text.strip(',').strip()
    
    return text

def normalize_text_for_language(text, language_code):
    """
    Normaliza o texto para evitar que o TTS mude de idioma.
    Remove ou substitui caracteres problemáticos.
    
    Args:
        text: Texto a ser normalizado
        language_code: Código do idioma
    
    Returns:
        Texto normalizado
    """
    # Remove múltiplos espaços
    text = re.sub(r'\s+', ' ', text).strip()
    
    # Remove URLs (podem fazer o TTS mudar de idioma)
    text = re.sub(r'http[s]?://\S+', '', text)
    
    # Remove emails
    text = re.sub(r'\S+@\S+\.\S+', '', text)
    
    # Remove hashtags e mentions (comum em textos de redes sociais)
    text = re.sub(r'[#@]\w+', '', text)
    
    # Remove números entre parênteses que podem confundir (ex: (2024), (1))
    text = re.sub(r'\(\d+\)', '', text)
    
    # Substitui aspas curvas por aspas retas (podem causar problemas)
    text = text.replace('"', '"').replace('"', '"')
    text = text.replace(''', "'").replace(''', "'")
    
    # Remove caracteres de controle invisíveis
    text = re.sub(r'[\x00-\x1F\x7F-\x9F]', '', text)
    
    # Para idiomas não-latinos, remove caracteres latinos que possam confundir
    if language_code in ['ja-JP', 'ko-KR', 'zh-CN', 'ar-SA', 'hi-IN']:
        # Mantém apenas pontuação e caracteres do idioma específico
        pass  # Pode adicionar filtros específicos se necessário
    
    return text.strip()

def split_text_into_chunks(text, min_words=70, max_words=450):
    """Divide o texto em chunks respeitando limites de palavras e evitando cortes"""
    text = re.sub(r'\s+', ' ', text).strip()
    
    sentences = re.split(r'(?<=[.!?])\s+', text)
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue

        words_in_sentence = len(sentence.split())
        words_in_current = len(current_chunk.split())

        if words_in_sentence > max_words:
            if current_chunk:
                chunks.append(current_chunk.strip())
            chunks.append(sentence)
            current_chunk = ""
            continue

        if words_in_current + words_in_sentence <= max_words:
            current_chunk += (" " if current_chunk else "") + sentence
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = sentence

    if current_chunk:
        chunks.append(current_chunk.strip())
        
    return chunks

def generate_audio_chunk(voice, text, output_audio, rate, pitch, language):
    """
    Gera áudio para um chunk de texto usando Edge TTS.
    
    IMPORTANTE: O parâmetro 'language' é usado para normalizar o texto,
    mas a voz já deve estar correta para o idioma desejado.
    """
    logger.debug(f"Iniciando generate_audio_chunk para voz: {voice}, idioma: {language}, output: {output_audio}")
    try:
        # 1. Força pronúncia correta do idioma (adiciona pausas estratégicas)
        clean_text = force_language_pronunciation(text, language)
        
        # 2. Substitui palavras problemáticas conhecidas
        clean_text = replace_problematic_words(clean_text, language)
        
        # 3. Normaliza o texto para evitar mudança de idioma
        clean_text = normalize_text_for_language(clean_text, language)
        
        # 4. Remove quebras de linha
        clean_text = clean_text.replace('\n', ' ').replace('\r', ' ').strip()
        
        if not clean_text:
            logger.warning("Texto vazio após normalização")
            return False, "Texto vazio após normalização"
        
        if text != clean_text:
            logger.debug(f"Texto modificado para forçar pronúncia:")
            logger.debug(f"  ANTES: {text[:100]}...")
            logger.debug(f"  DEPOIS: {clean_text[:100]}...")
        
        async def _generate():
            # Edge TTS - sintaxe básica
            communicate = edge_tts.Communicate(
                clean_text,
                voice,
                rate=rate,
                pitch=pitch
            )
            await communicate.save(output_audio)
        
        asyncio.run(_generate())
        
        if os.path.exists(output_audio):
            file_size = os.path.getsize(output_audio)
            logger.debug(f"Áudio gerado com sucesso: {output_audio} ({file_size} bytes)")
            return True, None
        else:
            logger.error(f"Falha ao criar o arquivo de áudio: {output_audio}")
            return False, "Falha ao criar o arquivo de áudio."

    except Exception as e:
        logger.critical(f"Erro inesperado em generate_audio_chunk: {e}", exc_info=True)
        return False, f"Erro inesperado ao gerar áudio: {e}"

def concatenate_audio_files(audio_files, output_file):
    """Concatena arquivos de áudio usando ffmpeg"""
    if not audio_files:
        logger.warning("Nenhum arquivo de áudio para concatenar.")
        return False, "Nenhum arquivo de áudio para concatenar."
    
    list_file = os.path.join(tempfile.gettempdir(), "temp_audio_list.txt")
    with open(list_file, 'w', encoding='utf-8') as f:
        for audio_file in audio_files:
            abs_path = os.path.abspath(audio_file).replace('\\', '/')
            f.write(f"file '{abs_path}'\n")
    
    try:
        # Verifica se o FFmpeg está disponível
        try:
            subprocess.run(['ffmpeg', "-version"], check=True, capture_output=True, creationflags=subprocess_flags)
        except FileNotFoundError:
            error_msg = ("ERRO: FFmpeg não encontrado! Por favor, instale o FFmpeg e adicione-o ao PATH do sistema."
                         "\nInstruções: https://ffmpeg.org/download.html")
            logger.error(error_msg)
            if os.path.exists(list_file): os.remove(list_file)
            return False, error_msg
        except subprocess.CalledProcessError as e:
            error_msg = f"ERRO: FFmpeg encontrado, mas falhou ao executar: {e.stderr}"
            logger.error(error_msg)
            if os.path.exists(list_file): os.remove(list_file)
            return False, error_msg

        cmd = [
            'ffmpeg', '-f', 'concat', '-safe', '0',
            '-i', list_file, '-c', 'copy', '-map_metadata', '-1', output_file, '-y'
        ]
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True,
                                    creationflags=subprocess_flags)
            os.remove(list_file)
            logger.info(f"Concatenação FFmpeg concluída com sucesso")
            logger.debug(f"FFmpeg STDOUT: {result.stdout}")
            logger.debug(f"FFmpeg STDERR: {result.stderr}")
            return True, None
        except subprocess.CalledProcessError as e:
            error_msg = f"Erro ao concatenar áudios: {e.stderr}"
            logger.error(f"Comando FFmpeg falhou: {' '.join(cmd)}")
            logger.error(error_msg)
            if os.path.exists(list_file): os.remove(list_file)
            return False, error_msg
    except Exception as e:
        error_msg = f"Erro inesperado ao concatenar áudios: {e}"
        logger.critical(f"Erro inesperado durante a concatenação: {e}", exc_info=True)
        if os.path.exists(list_file): os.remove(list_file)
        return False, error_msg

def process_text(text, voice, rate, pitch, language, progress_callback=None, preferred_gender="female"):
    """
    Processa um texto, converte para áudio, aplica o preset de alta qualidade "Estúdio CN"
    e retorna o caminho do arquivo final.
    
    Args:
        text: Texto a ser convertido em áudio
        voice: Nome da voz (se None, seleciona automaticamente baseado no idioma)
        rate: Taxa de velocidade (ex: "+0%", "+10%", "-10%")
        pitch: Tom de voz (ex: "+0Hz", "+5Hz", "-5Hz")
        language: Código do idioma (ex: "pt-BR", "en-US")
        progress_callback: Função de callback para reportar progresso
        preferred_gender: "female" ou "male" para seleção automática de voz
    
    Returns:
        (caminho_do_arquivo, None) em sucesso, ou (None, mensagem_de_erro) em falha.
    """
    # Seleciona a voz apropriada para o idioma
    effective_voice = get_voice_for_language(language, preferred_gender, voice)
    
    logger.info(f"=== INICIANDO PROCESSAMENTO TTS ===")
    logger.info(f"Idioma: {language}")
    logger.info(f"Voz: {effective_voice}")
    logger.info(f"Rate: {rate}, Pitch: {pitch}")
    
    chunks = split_text_into_chunks(text)
    if not chunks:
        logger.warning("Texto vazio ou não pôde ser dividido.")
        return None, "O texto está vazio ou não pôde ser dividido."

    total_chunks = len(chunks)
    temp_dir = tempfile.mkdtemp(prefix="tts_chunks_")
    temp_audio_files = []
    
    logger.info(f"Texto dividido em {total_chunks} chunks")

    try:
        for i, chunk in enumerate(chunks):
            logger.debug(f"Processando chunk {i+1}/{total_chunks} ({len(chunk)} caracteres)")
            temp_audio = os.path.join(temp_dir, f"chunk_{i:03d}.mp3")
            
            success, error = generate_audio_chunk(effective_voice, chunk, temp_audio, rate, pitch, language)
            if success:
                logger.debug(f"✓ Chunk {i+1} gerado com sucesso.")
                temp_audio_files.append(temp_audio)
                if progress_callback:
                    progress_callback(i + 1, total_chunks)
            else:
                logger.error(f"✗ Falha no chunk {i+1}: {error}")
                shutil.rmtree(temp_dir)
                return None, f"Falha ao gerar áudio para o chunk {i+1}: {error}"

        if not temp_audio_files:
            logger.warning("Nenhum áudio foi gerado com sucesso após processar chunks.")
            shutil.rmtree(temp_dir)
            return None, "Nenhum áudio foi gerado com sucesso."

        unprocessed_audio_path = os.path.join(tempfile.gettempdir(), f"unprocessed_tts_audio_{os.getpid()}.mp3")
        
        logger.info(f"Concatenando {len(temp_audio_files)} arquivos temporários")
        if len(temp_audio_files) == 1:
            logger.debug(f"Apenas um chunk, movendo diretamente")
            shutil.move(temp_audio_files[0], unprocessed_audio_path)
            success = True
            error = None
        else:
            success, error = concatenate_audio_files(temp_audio_files, unprocessed_audio_path)
            if not success:
                logger.error(f"Falha na concatenação dos áudios: {error}")
                shutil.rmtree(temp_dir)
                return None, error
        
        shutil.rmtree(temp_dir)
        logger.info(f"Arquivos temporários removidos")
        
        # Aplica pós-processamento
        audio_processor = TTSAudioProcessor()
        final_audio_path = os.path.join(tempfile.gettempdir(), f"final_processed_tts_audio_{os.getpid()}.mp3")
        
        logger.info(f"Aplicando preset 'Estúdio CN'")
        try:
            processed_path = audio_processor.processar_preset_estudio_cn(unprocessed_audio_path, final_audio_path)
            
            if os.path.exists(unprocessed_audio_path):
                os.remove(unprocessed_audio_path)
                logger.info(f"Áudio temporário removido")
                
            logger.info(f"=== PROCESSAMENTO CONCLUÍDO COM SUCESSO ===")
            logger.info(f"Arquivo final: {final_audio_path}")
            return final_audio_path, None

        except Exception as e:
            logger.critical(f"Falha ao aplicar o pós-processamento 'Estúdio CN': {e}", exc_info=True)
            if os.path.exists(unprocessed_audio_path):
                os.remove(unprocessed_audio_path)
            return None, f"Falha ao aplicar o pós-processamento 'Estúdio CN': {e}"

    except Exception as e:
        logger.critical(f"Erro geral no processamento de texto para áudio: {e}", exc_info=True)
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        return None, f"Erro geral no processamento: {e}"


# ============================================================================
# FUNÇÕES AUXILIARES PARA LISTAR VOZES DISPONÍVEIS
# ============================================================================

def list_available_languages():
    """Retorna lista de idiomas suportados"""
    return list(VOICE_MAPPING.keys())

def list_voices_for_language(language_code):
    """Retorna todas as vozes disponíveis para um idioma"""
    if language_code in VOICE_MAPPING:
        return {
            "female": VOICE_MAPPING[language_code].get("female", []),
            "male": VOICE_MAPPING[language_code].get("male", [])
        }
    return {"female": [], "male": []}

def get_all_voices():
    """Retorna todas as vozes mapeadas"""
    all_voices = {}
    for lang, genders in VOICE_MAPPING.items():
        all_voices[lang] = {
            "female": genders.get("female", []),
            "male": genders.get("male", [])
        }
    return all_voices


# ============================================================================
# TESTE DO MÓDULO
# ============================================================================

if __name__ == "__main__":
    # Configura logging para teste
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("=== TESTE DO TEXT_TO_SPEECH_PROCESSOR ===\n")
    
    # Lista idiomas disponíveis
    print("Idiomas disponíveis:")
    for lang in list_available_languages():
        print(f"  {lang}")
    
    print("\n" + "="*50 + "\n")
    
    # Teste básico
    test_text = "Este é um teste do sistema de conversão de texto para fala."
    
    print(f"Gerando áudio de teste em português...")
    result, error = process_text(
        text=test_text,
        voice=None,  # Seleção automática
        rate="+0%",
        pitch="+0Hz",
        language="pt-BR",
        preferred_gender="female"
    )
    
    if result:
        print(f"✓ Sucesso! Arquivo gerado: {result}")
    else:
        print(f"✗ Erro: {error}")